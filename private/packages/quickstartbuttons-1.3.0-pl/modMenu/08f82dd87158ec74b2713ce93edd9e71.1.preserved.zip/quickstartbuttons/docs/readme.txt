--------------------------------------------
QuickstartButtons - Managing dashboard quickstart buttons
--------------------------------------------
Author: Bert Oost - support@oostdesign.com
--------------------------------------------

A MODX Revolution 2.2+ dashboard widget to manage quickstart buttons
