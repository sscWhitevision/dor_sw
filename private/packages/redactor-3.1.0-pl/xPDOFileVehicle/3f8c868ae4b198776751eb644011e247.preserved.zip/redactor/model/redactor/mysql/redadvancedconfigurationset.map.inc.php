<?php
$xpdo_meta_map['redAdvancedConfigurationSet']= array (
  'package' => 'redactor',
  'version' => '1.1',
  'extends' => 'redConfigurationSet',
  'tableMeta' => 
  array (
    'engine' => 'InnoDB',
  ),
  'fields' => 
  array (
  ),
  'fieldMeta' => 
  array (
  ),
);
