<?php
require_once (dirname(dirname(__FILE__)) . '/redadvancedconfigurationset.class.php');
class redAdvancedConfigurationSet_mysql extends redAdvancedConfigurationSet {}