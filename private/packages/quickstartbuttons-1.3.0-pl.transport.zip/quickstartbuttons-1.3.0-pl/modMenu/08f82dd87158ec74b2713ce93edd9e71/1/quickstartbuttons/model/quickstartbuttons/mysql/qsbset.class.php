<?php
require_once (dirname(dirname(__FILE__)) . '/qsbset.class.php');
class qsbSet_mysql extends qsbSet {}