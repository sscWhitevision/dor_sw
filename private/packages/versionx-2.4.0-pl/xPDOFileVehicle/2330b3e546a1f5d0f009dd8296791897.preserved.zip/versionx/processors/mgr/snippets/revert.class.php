<?php
require_once dirname(__DIR__) . '/revert.class.php';

class VersionXSnippetsRevertProcessor extends VersionXRevertProcessor {
    public $classKey = 'vxSnippet';
}

return 'VersionXSnippetsRevertProcessor';
