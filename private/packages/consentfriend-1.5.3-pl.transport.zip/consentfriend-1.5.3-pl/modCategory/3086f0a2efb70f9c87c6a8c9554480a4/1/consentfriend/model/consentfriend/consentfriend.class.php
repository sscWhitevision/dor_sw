<?php
/**
 * ConsentFriend
 *
 * Copyright 2020-2022 by Thomas Jakobi <office@treehillstudio.com>
 *
 * @package consentfriend
 * @subpackage classfile
 */

require_once dirname(dirname(__DIR__)) . '/vendor/autoload.php';

/**
 * Class ConsentFriend
 */
class ConsentFriend extends \TreehillStudio\ConsentFriend\ConsentFriend
{
}
