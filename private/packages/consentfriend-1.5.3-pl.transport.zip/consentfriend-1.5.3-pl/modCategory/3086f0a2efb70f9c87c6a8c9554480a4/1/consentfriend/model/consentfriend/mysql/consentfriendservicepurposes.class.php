<?php
/**
 * @package consentfriend
 */
require_once (strtr(realpath(dirname(dirname(__FILE__))), '\\', '/') . '/consentfriendservicepurposes.class.php');
class ConsentfriendServicePurposes_mysql extends ConsentfriendServicePurposes {}
?>