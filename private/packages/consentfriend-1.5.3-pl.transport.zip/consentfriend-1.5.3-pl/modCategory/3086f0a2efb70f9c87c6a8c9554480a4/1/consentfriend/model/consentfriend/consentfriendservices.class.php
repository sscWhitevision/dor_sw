<?php
/**
 * @package consentfriend
 */
class ConsentfriendServices extends xPDOSimpleObject {}
?>