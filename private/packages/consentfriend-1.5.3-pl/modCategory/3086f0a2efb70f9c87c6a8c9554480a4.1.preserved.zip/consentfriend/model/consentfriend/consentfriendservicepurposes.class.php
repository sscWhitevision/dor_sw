<?php
/**
 * @package consentfriend
 */
class ConsentfriendServicePurposes extends xPDOSimpleObject {}
?>