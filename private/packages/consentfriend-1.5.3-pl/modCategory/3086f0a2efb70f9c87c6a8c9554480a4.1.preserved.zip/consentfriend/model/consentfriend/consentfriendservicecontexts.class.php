<?php
/**
 * @package consentfriend
 */
class ConsentfriendServiceContexts extends xPDOSimpleObject {}
?>