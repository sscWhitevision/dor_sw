<?php
$_lang['redactor.permission.configurator'] = 'Accès au configurateur de Redactor';
$_lang['redactor.permission.sets_view'] = 'Permet de visualiser la configuration d\'un ensemble donné';
$_lang['redactor.permission.sets_create'] = 'Permet de créer de nouveaux ensembles de configuration';
$_lang['redactor.permission.sets_delete'] = 'Permet de supprimer des ensembles de configuration existants';
$_lang['redactor.permission.sets_export'] = 'Permet d\'exporter des jeux de configuration vers un fichier XML';
$_lang['redactor.permission.sets_import'] = 'Permet d\'importer des ensembles de configuration à partir d\'un fichier d\'exportation. Nécessite également les droits sets_create, sets_delete et sets_save.';
$_lang['redactor.permission.sets_save'] = 'Permet d\'éditer et de sauvegarder les jeux de configuration';
