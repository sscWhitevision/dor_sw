<?php
/**
 * @package consentfriend
 */
class ConsentfriendPurposes extends xPDOSimpleObject {}
?>