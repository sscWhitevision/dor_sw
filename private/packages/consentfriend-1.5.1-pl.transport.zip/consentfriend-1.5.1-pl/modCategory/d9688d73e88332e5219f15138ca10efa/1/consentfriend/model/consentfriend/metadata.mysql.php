<?php

$xpdo_meta_map = array (
  'xPDOSimpleObject' => 
  array (
    0 => 'ConsentfriendServices',
    1 => 'ConsentfriendServicePurposes',
    2 => 'ConsentfriendPurposes',
    3 => 'ConsentfriendServiceContexts',
    4 => 'ConsentfriendLogs',
  ),
);