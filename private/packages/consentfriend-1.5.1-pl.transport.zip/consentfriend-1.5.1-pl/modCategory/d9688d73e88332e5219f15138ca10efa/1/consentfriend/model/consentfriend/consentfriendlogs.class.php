<?php
/**
 * @package consentfriend
 */
class ConsentfriendLogs extends xPDOSimpleObject {}
?>