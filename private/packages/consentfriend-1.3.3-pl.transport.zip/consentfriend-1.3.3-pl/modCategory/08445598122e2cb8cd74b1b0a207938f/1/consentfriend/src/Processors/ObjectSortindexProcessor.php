<?php
/**
 * Abstract sortindex processor
 *
 * @package consentfriend
 * @subpackage processor
 */

namespace TreehillStudio\ConsentFriend\Processors;

use ConsentFriend;
use modObjectProcessor;
use modX;
use xPDOObject;

/**
 * Class ObjectSortindexProcessor
 */
abstract class ObjectSortindexProcessor extends modObjectProcessor
{
    public $languageTopics = ['consentfriend:default'];
    public $indexKey = 'sortindex';

    /** @var ConsentFriend */
    public $consentfriend;

    /**
     * {@inheritDoc}
     * @param modX $modx A reference to the modX instance
     * @param array $properties An array of properties
     */
    function __construct(modX & $modx, array $properties = []) {
        parent::__construct($modx, $properties);

        $corePath = $this->modx->getOption('consentfriend.core_path', null, $this->modx->getOption('core_path') . 'components/consentfriend/');
        $this->consentfriend =& $this->modx->getService('consentfriend', 'ConsentFriend', $corePath . 'model/consentfriend/');
    }

    /**
     * {@inheritDoc}
     * @return array|string
     */
    public function process()
    {
        if (!$this->cleanSorting()) {
            return $this->failure();
        }

        $targetId = $this->getProperty('targetId');
        $targetIndex = $this->modx->getObject($this->classKey, $targetId)->get($this->indexKey);

        // Prepare the moving ids
        $movingIds = explode(',', $this->getProperty('movingIds', 0));
        $c = $this->modx->newQuery($this->classKey);
        $c->where([
            'id:IN' => $movingIds
        ]);
        $c->sortby($this->indexKey);
        $c->sortby('id');
        /** @var xPDOObject[] $movingObjects */
        $movingObjects = $this->modx->getIterator($this->classKey, $c);
        foreach ($movingObjects as $movingObject) {
            $c = $this->modx->newQuery($this->classKey);
            $movingIndex = $movingObject->get($this->indexKey);
            if ($movingIndex < $targetIndex) {
                $c->where([
                    $this->indexKey . ':>' => $movingIndex,
                    $this->indexKey . ':<=' => $targetIndex,
                ]);
            } else {
                $c->where([
                    $this->indexKey . ':<' => $movingIndex,
                    $this->indexKey . ':>=' => $targetIndex,
                ]);
            }
            $c->sortby($this->indexKey);
            $c->sortby('id');
            /** @var xPDOObject[] $affectedObjects */
            $affectedObjects = $this->modx->getIterator($this->classKey, $c);
            foreach ($affectedObjects as $affectedObject) {
                $affectedIndex = $affectedObject->get($this->indexKey);
                if ($movingIndex < $targetIndex) {
                    $newIndex = $affectedIndex - 1;
                } else {
                    $newIndex = $affectedIndex + 1;
                }
                $affectedObject->set($this->indexKey, $newIndex);
                $affectedObject->save();
            }
            $movingObject->set($this->indexKey, $targetIndex);
            $movingObject->save();
        }

        return $this->success();
    }

    /**
     * Clean the current sorting.
     *
     * @return bool
     */
    private function cleanSorting(): bool
    {
        $c = $this->modx->newQuery($this->classKey);
        $c->sortby($this->indexKey);
        $c->sortby('id');

        /** @var xPDOObject[] $objects */
        $objects = $this->modx->getIterator($this->classKey, $c);
        if (!$objects) {
            return false;
        }

        $i = 0;
        foreach ($objects as $object) {
            $object->set($this->indexKey, $i);
            $object->save();
            $i++;
        }
        return true;
    }
}

return 'ConsentfriendPurposesSortindexProcessor';
