ConsentFriend is proprietary software, developed by Thomas Jakobi for Treehill
Studio. By purchasing ConsentFriend you have received a usage license for one
single MODX Revolution installation, including one year email support (starting
at the day of purchase).

While we hope that ConsentFriend is useful for you and we will try to help you
successfully use ConsentFriend, Treehill Studio is not liable for loss of
revenue, damages or other financial loss resulting from the installation or use
of ConsentFriend.

By using and installing this package, you acknowledge that you shall only use
this on one single MODX installation.

Redistribution in any shape or form is strictly prohibited. You may customize or
change the provided source code of ConsentFriend for your own needs, as long as
there is no attempt to remove the license protection code. By changing the
source code you acknowledge that you lose your right of support unless the code
change is coordinated with the support of Treehill Studio.
